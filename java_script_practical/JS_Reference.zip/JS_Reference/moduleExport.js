export const a = Number(prompt("Enter Firts Number Value"));
const b = Number(prompt("Enter Second Number Value"));
const sum = a + b;
export { b };
export { sum };
