// In Module, Import Export Always  
console.log("Js Start Here");

import { a } from "./moduleExport.js";
import { b } from "./moduleExport.js";
import { sum as add} from "./moduleExport.js";
console.log(a);
console.log(b);
console.log(add);
