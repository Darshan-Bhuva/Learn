"use strict";
// "use strict" Is Define All Types Of Error Means Now Js Run On Strict Mode
function my(a, a) {
  console.log(a);
}
my(10, 11);
